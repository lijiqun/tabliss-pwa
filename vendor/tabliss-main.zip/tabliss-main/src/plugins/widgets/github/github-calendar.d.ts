declare module "github-calendar";
